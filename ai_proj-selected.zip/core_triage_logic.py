import cv2
import os
from PIL import Image
import numpy as np
import torch
import gc # For garbage collection to free up memory
import streamlit as st # Only used for st.cache_resource here

# Import YOLO model
from ultralytics import YOLO

# Import BLIP and other transformers
from transformers import BlipProcessor, BlipForConditionalGeneration, BlipForQuestionAnswering 
# Optional: Uncomment and configure for actual Llama integration:
# from transformers import AutoTokenizer, AutoModelForCausalLM 

# --- Global Configuration ---
# Check for GPU availability
USE_CUDA = torch.cuda.is_available()
DEVICE = "cuda" if USE_CUDA else "cpu"
print(f"Using device: {DEVICE}") # This will print to the Streamlit console/terminal

# Temporary directory for cropped human images (BLIP needs file paths)
CROPPED_HUMANS_TEMP_DIR = "cropped_humans_temp"

# --- Model Loading (Cached for Efficiency) ---
# Streamlit's @st.cache_resource decorator ensures models are loaded only once,
# even if the Streamlit app reruns.

@st.cache_resource
def load_yolo_model():
    """Loads the YOLOv5s model for human detection."""
    st.info("Loading YOLOv5 model... This may take a moment.")
    model = YOLO('yolov5s.pt') # Using the small YOLOv5 model for balance
    if USE_CUDA:
        model.to(DEVICE)
    st.success("YOLOv5 model loaded!")
    return model

@st.cache_resource
def load_blip_models():
    """Loads BLIP models for image captioning and visual question answering."""
    st.info("Loading BLIP models... This may take a moment.")
    processor_caption = BlipProcessor.from_pretrained("Salesforce/blip-image-captioning-base")
    model_caption = BlipForConditionalGeneration.from_pretrained("Salesforce/blip-image-captioning-base")
    if USE_CUDA:
        model_caption.to(DEVICE)

    processor_vqa = BlipProcessor.from_pretrained("Salesforce/blip-vqa-base")
    model_vqa = BlipForQuestionAnswering.from_pretrained("Salesforce/blip-vqa-base")
    if USE_CUDA:
        model_vqa.to(DEVICE)
    st.success("BLIP models loaded!")
    return processor_caption, model_caption, processor_vqa, model_vqa

# --- Llama Model Loading (Optional) ---
# Uncomment and configure if you have Llama 2 access and token.
# @st.cache_resource
# def load_llama_model():
#     """Loads a Llama model for advanced triage classification."""
#     st.info("Attempting to load Llama model... This requires a Hugging Face token.")
#     HF_TOKEN = st.secrets["HF_TOKEN"] # Recommended way to store secrets in Streamlit
#     try:
#         tokenizer = AutoTokenizer.from_pretrained("meta-llama/Llama-2-7b-chat-hf", token=HF_TOKEN)
#         model = AutoModelForCausalLM.from_pretrained("meta-llama/Llama-2-7b-chat-hf", token=HF_TOKEN)
#         if USE_CUDA:
#             model.to(DEVICE)
#         st.success("Llama model loaded successfully!")
#         return tokenizer, model
#     except Exception as e:
#         st.warning(f"Could not load Llama model: {e}. Falling back to rule-based triage.")
#         return None, None

# --- Initialize Models on App Startup ---
yolo_model = load_yolo_model()
blip_processor_caption, blip_model_caption, blip_processor_vqa, blip_model_vqa = load_blip_models()
# llama_tokenizer, llama_model = load_llama_model() # Uncomment if using Llama

# --- Core AI Processing Functions ---

def detect_humans_yolo(frame, confidence_threshold=0.5):
    """
    Detects humans in a single frame using the pre-loaded YOLO model.
    Returns a list of detected human bounding boxes and their confidence scores.
    """
    # YOLO handles image preprocessing internally
    results = yolo_model(frame, verbose=False) 

    human_detections = []
    for r in results: # Results object from YOLO
        for *xyxy, conf, cls in r.boxes: # Unpack detection details
            class_name = yolo_model.names[int(cls)] 
            if class_name == "person" and conf.item() > confidence_threshold:
                x_min, y_min, x_max, y_max = [int(val) for val in xyxy]
                human_detections.append({
                    "box": (x_min, y_min, x_max, y_max),
                    "score": conf.item()
                })
    return human_detections

def save_cropped_human_image(frame, detection_box, output_dir=CROPPED_HUMANS_TEMP_DIR):
    """
    Saves a cropped image of the detected human to a temporary directory.
    This is necessary as BLIP models typically expect an image file path.
    Returns the path to the saved image or None if cropping fails.
    """
    os.makedirs(output_dir, exist_ok=True)
    x_min, y_min, x_max, y_max = detection_box
    
    # Clamp coordinates to frame dimensions to avoid errors
    h, w, _ = frame.shape
    x_min, y_min = max(0, x_min), max(0, y_min)
    x_max, y_max = min(w, x_max), min(h, y_max)

    if x_max > x_min and y_max > y_min:
        cropped_human = frame[y_min:y_max, x_min:x_max]
        # Generate a unique temporary filename
        temp_path = os.path.join(output_dir, f"temp_human_crop_{os.getpid()}_{np.random.randint(100000)}.jpg")
        cv2.imwrite(temp_path, cropped_human)
        return temp_path
    return None

def get_blip_description(image_path):
    """
    Generates a descriptive caption and answers specific questions about an image using BLIP models.
    The description provides context for triage classification.
    """
    if not image_path or not os.path.exists(image_path):
        return "No image available for description."

    raw_image = Image.open(image_path).convert('RGB')
    
    # 1. Generate a general caption
    inputs_caption = blip_processor_caption(raw_image, return_tensors="pt").to(DEVICE)
    out_caption = blip_model_caption.generate(**inputs_caption)
    caption = blip_processor_caption.decode(out_caption[0], skip_special_tokens=True)

    # 2. Ask targeted Visual Question Answering (VQA) questions
    vqa_questions = [
        "What is the person doing?", "What is the person's posture?", 
        "Does the person appear to be in distress?", "Is there any object in the person's hand?",
        "Is the person standing, sitting, or lying down?", "Is the person alone?",
        "Are there any signs of aggressive behavior?", "What is the person's expression?",
        "Is the person injured?" # Added for better triage
    ]
    vqa_answers = []
    for q in vqa_questions:
        inputs_vqa = blip_processor_vqa(raw_image, q, return_tensors="pt").to(DEVICE)
        out_vqa = blip_model_vqa.generate(**inputs_vqa)
        answer = blip_processor_vqa.decode(out_vqa[0], skip_special_tokens=True)
        vqa_answers.append(f"Q: {q} A: {answer}")

    full_description = f"Caption: {caption}. " + " ".join(vqa_answers)
    
    # Clear CUDA memory to prevent out-of-memory errors on GPU
    if USE_CUDA:
        torch.cuda.empty_cache()
        gc.collect() 
        
    return full_description

def classify_triage_llama(blip_description):
    """
    Classifies the BLIP description into one of five triage levels.
    Prioritizes Llama if loaded, otherwise falls back to keyword-based logic.
    """
    triage_levels_description = """
    - **Level 1 (Critical/Immediate Action):** High-risk, immediate intervention needed. Examples: falling, struggling, unconsciousness, visible weapon, active violence, significant injury, fire, smoke, medical emergency.
    - **Level 2 (Urgent/Rapid Response):** Potentially problematic situation, prompt attention. Examples: suspicious loitering, unusual gathering, aggressive posture/behavior, unauthorized access, disorientation, signs of minor injury, verbal confrontation.
    - **Level 3 (Moderate/Routine Review):** Normal human presence or activity, warrants routine check/logging. Examples: walking, talking, working, waiting in a designated area, brief passage, minor non-threatening interaction.
    - **Level 4 (Minor/Low Priority):** Fleeting or background human presence, no significant activity. Examples: person briefly visible at frame edge, distant figures, ambiguous movement, person simply passing by.
    - **Level 5 (Informational/No Action):** Clearly benign situation, no further action beyond logging. Examples: cleaning staff, delivery personnel, authorized personnel performing routine tasks, clearly resting or relaxed.
    """

    prompt = f"""Analyze the following description of human activity from a video frame and classify it into one of the five triage levels.
    {triage_levels_description}

    Description: "{blip_description}"

    Based on this description, what is the most appropriate triage level (1, 2, 3, 4, or 5)?
    Provide only the level number and a very brief justification (1-2 sentences).
    Example output format:
    Level: 1
    Reason: Person appears unconscious and bleeding.
    ---
    """
    
    # --- Llama Integration (Uncomment and configure if used) ---
    # if 'llama_model' in globals() and llama_model is not None:
    #     try:
    #         inputs = llama_tokenizer(prompt, return_tensors="pt", truncation=True, max_length=1024).to(DEVICE)
    #         outputs = llama_model.generate(
    #             inputs.input_ids, 
    #             max_new_tokens=100, 
    #             num_return_sequences=1,
    #             pad_token_id=llama_tokenizer.eos_token_id, 
    #             do_sample=True, top_k=50, top_p=0.95, temperature=0.7
    #         )
    #         llama_response = llama_tokenizer.decode(outputs[0], skip_special_tokens=True)
    #         
    #         start_idx = llama_response.find("---") + 3
    #         if start_idx != -1:
    #             llama_response = llama_response[start_idx:].strip()

    #         level = "N/A"
    #         reason = "Could not parse Llama response."
    #         for line in llama_response.split('\n'):
    #             if "Level:" in line:
    #                 level = line.split("Level:")[1].strip()
    #             elif "Reason:" in line:
    #                 reason = line.split("Reason:")[1].strip()
    #         
    #         if USE_CUDA:
    #             torch.cuda.empty_cache()
    #             gc.collect()
    #         return level, reason
    #     except Exception as e:
    #         # Fallback on Llama error
    #         pass 
        
    # --- Fallback to keyword-based classification ---
    blip_desc_lower = blip_description.lower()
    
    if any(keyword in blip_desc_lower for keyword in ["falling", "struggling", "unconscious", "weapon", "attacking", "bleeding", "fire", "smoke", "collapsed", "violent", "screaming", "danger", "victim", "serious injury", "active shooter", "medical emergency"]):
        return "1", "High-risk, immediate intervention needed."
    elif any(keyword in blip_desc_lower for keyword in ["loitering", "suspicious", "aggressive", "fighting", "trespassing", "disoriented", "shouting", "arguing", "running suddenly", "hiding", "unusual gathering", "trying to open", "breaking", "damaged", "minor injury", "confrontation"]):
        return "2", "Potentially problematic, prompt attention."
    elif any(keyword in blip_desc_lower for keyword in ["walking", "standing", "sitting", "working", "talking", "normal", "routine", "waiting", "interacting", "looking around", "entering", "exiting", "conversing"]):
        return "3", "Normal activity, routine review."
    elif any(keyword in blip_desc_lower for keyword in ["briefly visible", "distant", "ambiguous movement", "in background", "partially visible", "passing by quickly", "blurry"]):
        return "4", "Low priority, minimal activity."
    else: 
        return "5", "Benign activity, informational only."