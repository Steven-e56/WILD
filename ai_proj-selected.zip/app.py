import streamlit as st
import cv2
import os
import time
import numpy as np
import shutil # For cleaning up temporary directories

# Import the core AI logic functions and configurations
from core_triage_logic import (
    detect_humans_yolo, save_cropped_human_image,
    get_blip_description, classify_triage_llama,
    CROPPED_HUMANS_TEMP_DIR
)

# --- Streamlit UI Setup ---
st.set_page_config(
    page_title="AI Video Triage System",
    layout="wide", # Use wide layout for more space
    initial_sidebar_state="expanded",
    icon="👁️"
)

st.title("AI Video Triage System 👁️‍🗨️")
st.markdown("---")

st.markdown("""
Welcome to the AI Video Triage System! This application uses advanced AI models to detect humans in a video stream, understand their activities, and classify potential risks based on a 5-level triage system.

**How it works:**
1.  **Human Detection:** YOLO identifies any people in the video.
2.  **Contextual Understanding:** BLIP analyzes the detected person's image to describe their actions and state.
3.  **Triage Classification:** The system (using a rule-based fallback or an LLM like Llama if enabled) assesses the description and assigns a triage level (1-5).
""")
st.markdown("---")


# --- Global Variables for Session State ---
# These variables persist across Streamlit reruns
if 'running' not in st.session_state:
    st.session_state.running = False # Is the video stream currently running?
if 'cap' not in st.session_state:
    st.session_state.cap = None # OpenCV video capture object

# --- UI Layout ---
# Use columns to neatly arrange the video feed and results side-by-side
col1, col2 = st.columns([2, 1]) # Column 1 for video (2x wider), Column 2 for results

with col1:
    st.subheader("Live Video Feed")
    # Placeholder for the actual video frames
    video_placeholder = st.empty() 
    # Placeholder for general detection info (e.g., "Humans detected: 2")
    detection_info_placeholder = st.empty() 

with col2:
    st.subheader("Triage Alerts & Details")
    # Displays information about the current frame being processed
    current_frame_info = st.empty() 
    # Container for detailed information about each detected human and their triage status
    human_details_container = st.container() 

st.markdown("---")

# --- Sidebar for Settings ---
st.sidebar.header("Configuration")
st.sidebar.markdown("Adjust these settings to customize the detection and processing.")

# Input Source Selection
input_type = st.sidebar.radio(
    "Choose Video Source:",
    ("Live Webcam", "Upload Video File"),
    help="Select whether to use your computer's webcam or upload a video file."
)

video_file_path = None
camera_index = 0

if input_type == "Live Webcam":
    camera_index = st.sidebar.number_input(
        "Webcam Index (0 for default):", 
        min_value=0, 
        value=0, 
        step=1,
        help="Usually 0 is your built-in webcam. Try 1, 2, etc., if you have multiple."
    )
elif input_type == "Upload Video File":
    uploaded_file = st.sidebar.file_uploader(
        "Drag & Drop or Click to Upload Video:", 
        type=["mp4", "avi", "mov"],
        help="Upload a video file to analyze. Larger files may take longer to process."
    )
    if uploaded_file:
        # Save uploaded file to a temporary location for OpenCV to read
        temp_video_dir = "uploaded_videos_temp"
        os.makedirs(temp_video_dir, exist_ok=True)
        video_file_path = os.path.join(temp_video_dir, uploaded_file.name)
        with open(video_file_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
        st.sidebar.success(f"Video '{uploaded_file.name}' ready for processing.")
    else:
        st.sidebar.info("Please upload a video file to proceed.")


# Detection Parameters
st.sidebar.markdown("### Detection Settings")
confidence_threshold = st.sidebar.slider(
    "Human Detection Confidence:", 
    0.0, 1.0, 0.5, 0.05,
    help="Adjust how confident the AI must be to consider something a human (higher = fewer detections, less false positives)."
)
frame_skip_interval = st.sidebar.slider(
    "Process Every Nth Frame:", 
    1, 30, 1, 
    help="To improve performance, process only every Nth frame. '1' means every frame, '5' means every 5th frame."
)

# --- Start/Stop Controls ---
st.sidebar.markdown("---")
col_start_stop_1, col_start_stop_2 = st.sidebar.columns(2)

if col_start_stop_1.button("▶️ Start Analysis", type="primary"):
    if (input_type == "Live Webcam") or \
       (input_type == "Upload Video File" and video_file_path and os.path.exists(video_file_path)):
        st.session_state.running = True
        st.sidebar.success("Starting video analysis...")
    else:
        st.sidebar.warning("Please select a valid video source (webcam or uploaded file) to start.")

if col_start_stop_2.button("⏹️ Stop Analysis", type="secondary"):
    st.session_state.running = False
    if st.session_state.cap:
        st.session_state.cap.release()
        st.session_state.cap = None
    st.sidebar.info("Analysis stopped.")
    # Clean up temporary cropped images directory
    if os.path.exists(CROPPED_HUMANS_TEMP_DIR):
        shutil.rmtree(CROPPED_HUMANS_TEMP_DIR)
        # st.sidebar.text("Cleaned up temp files.") # Optional for user

st.sidebar.markdown("---")
st.sidebar.markdown("Developed with ❤️ by Your AI Team")


# --- Main Video Processing Loop ---
def process_video_stream():
    """
    Handles the main loop for capturing frames, running AI models, and updating the UI.
    """
    if input_type == "Live Webcam":
        st.session_state.cap = cv2.VideoCapture(camera_index)
    elif input_type == "Upload Video File":
        if video_file_path and os.path.exists(video_file_path):
            st.session_state.cap = cv2.VideoCapture(video_file_path)
        else:
            st.error("No valid video file selected or uploaded.")
            st.session_state.running = False
            return

    if not st.session_state.cap.isOpened():
        st.error(f"Error: Could not open video source (Index: {camera_index} or File: {video_file_path}). "
                 "Check camera connection or file path.")
        st.session_state.running = False
        return

    frame_count = 0
    while st.session_state.running:
        ret, frame = st.session_state.cap.read()
        if not ret:
            st.warning("End of video stream or camera disconnected. Stopping analysis.")
            st.session_state.running = False
            break

        frame_count += 1
        
        # Only process every Nth frame for performance
        if frame_count % frame_skip_interval != 0:
            # Still display the frame for smooth video playback
            video_placeholder.image(frame, channels="BGR", use_column_width=True)
            time.sleep(0.01) # Small delay to avoid busy-waiting for UI
            continue

        # --- AI Processing ---
        
        # 1. Human Detection
        detections = detect_humans_yolo(frame, confidence_threshold)

        display_frame = frame.copy() # Make a copy for drawing bounding boxes

        if detections:
            detection_info_placeholder.info(f"Humans detected in frame {frame_count}: {len(detections)} instance(s).")
            
            with human_details_container:
                human_details_container.empty() # Clear previous human details
                st.markdown("### Latest Human Detections:")

                for i, det in enumerate(detections):
                    bbox = det['box']
                    score = det['score']
                    x_min, y_min, x_max, y_max = bbox

                    # Draw bounding box on the frame
                    cv2.rectangle(display_frame, (x_min, y_min), (x_max, y_max), (0, 255, 0), 2)
                    cv2.putText(display_frame, f'Human {i+1} ({score:.2f})', (x_min, y_min - 10), 
                                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

                    # 2. Save cropped human image for BLIP
                    cropped_human_path = save_cropped_human_image(frame, bbox)
                    if cropped_human_path:
                        # 3. Get Contextual Description from BLIP
                        blip_description = get_blip_description(cropped_human_path)
                        
                        # 4. Classify Triage Level
                        triage_level, triage_reason = classify_triage_llama(blip_description)
                        
                        # Display results in UI
                        st.markdown(f"**Person {i+1} (Frame {frame_count})**")
                        st.image(cv2.cvtColor(cv2.imread(cropped_human_path), cv2.COLOR_BGR2RGB), caption=f"Cropped Human {i+1}", width=200)
                        st.write(f"**Confidence:** `{score:.2f}`")
                        st.write(f"**BLIP Says:** `{blip_description}`")
                        
                        # Use color-coding for triage levels
                        color_map = {
                            "1": "red", "2": "orange", "3": "blue", "4": "gray", "5": "green", "N/A": "black"
                        }
                        triage_color = color_map.get(triage_level, "black")
                        st.markdown(f"**Triage Level: <span style='color:{triage_color}'>Level {triage_level}</span>**", unsafe_allow_html=True)
                        st.write(f"**Reason:** `{triage_reason}`")
                        st.markdown("---")

                        # Clean up temporary cropped image
                        try:
                            os.remove(cropped_human_path)
                        except OSError as e:
                            print(f"Warning: Could not remove temporary file {cropped_human_path}: {e}")
                    else:
                        st.warning(f"Could not process cropped image for human {i+1} in frame {frame_count}.")
        else:
            detection_info_placeholder.info(f"No humans detected in frame {frame_count}.")
            with human_details_container:
                human_details_container.empty() # Clear previous human details
                st.write("Waiting for human detections...")

        # Update the main video feed with bounding boxes
        video_placeholder.image(display_frame, channels="BGR", use_column_width=True)
        
        # Display current frame info
        current_frame_info.markdown(f"Processing Frame: **{frame_count}** (Skipped: {frame_skip_interval-1} frames between analyses)")

        time.sleep(0.01) # Small delay to make the UI update smoothly

    # After loop ends
    if st.session_state.cap:
        st.session_state.cap.release()
        st.session_state.cap = None
    if os.path.exists(CROPPED_HUMANS_TEMP_DIR):
        shutil.rmtree(CROPPED_HUMANS_TEMP_DIR)
    st.info("Video analysis finished or stopped.")


# --- Run the processing loop when "running" state is True ---
if st.session_state.running:
    process_video_stream()